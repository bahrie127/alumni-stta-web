<?php
$resource_path=$this->config->item('base_url').$this->config->item('resources_path');
$base_url=$this->config->item('base_url')."index.php";?>

<div class="ms-gallery-template g-mt-50" id="ms-gallery-1">
    <!-- masterslider -->
    <div class="master-slider ms-skin-black-2 round-skin" id="masterslider">
        <div class="ms-slide">
            <img src="<?php echo $resource_path; ?>/images/gallery/blank.gif" data-src="<?php echo $resource_path; ?>/images/gallery/1.jpg" alt="lorem ipsum dolor sit" />
            <img src="<?php echo $resource_path; ?>/images/gallery/1-thumb.jpg" alt="thumb-1" class="ms-thumb" />
            <div class="ms-info">
                LOREM IPSUM DOLOR SIT AMET
            </div>
        </div>
        <div class="ms-slide">
            <img src="<?php echo $resource_path; ?>/images/gallery/blank.gif" data-src="<?php echo $resource_path; ?>/images/gallery/2.jpg" alt="lorem ipsum dolor sit" />
            <img src="<?php echo $resource_path; ?>/images/gallery/2-thumb.jpg" alt="thumb-2" class="ms-thumb" />
            <div class="ms-info">
                CONSECTETUR ADIPISCING ELIT
            </div>
        </div>
        <div class="ms-slide">
            <img src="<?php echo $resource_path; ?>/images/gallery/blank.gif" data-src="<?php echo $resource_path; ?>/images/gallery/3.jpg" alt="lorem ipsum dolor sit" />
            <img src="<?php echo $resource_path; ?>/images/gallery/3-thumb.jpg" alt="thumb-3" class="ms-thumb" />
            <div class="ms-info">
                SUSPENDISSE UT PULVINAR MAURIS
            </div>
        </div>
        <div class="ms-slide">
            <img src="<?php echo $resource_path; ?>/images/gallery/blank.gif" data-src="<?php echo $resource_path; ?>/images/gallery/4.jpg" alt="lorem ipsum dolor sit" />
            <img src="<?php echo $resource_path; ?>/images/gallery/4-thumb.jpg" alt="thumb-4" class="ms-thumb" />
            <div class="ms-info">
                SED DAPIBUS SIT AMET FELIS
            </div>
        </div>
        <div class="ms-slide">
            <img src="<?php echo $resource_path; ?>/images/gallery/blank.gif" data-src="<?php echo $resource_path; ?>/images/gallery/cover.jpg" alt="lorem ipsum dolor sit" />
            <a href="http://player.vimeo.com/video/53914149" data-type="video"> vimeo video </a>
            <img src="<?php echo $resource_path; ?>/images/gallery/cover-thumb.jpg" alt="thumb-4" class="ms-thumb" />
            <div class="ms-info">
                YOUTUBE AND VIMEO VIDEOS
            </div>
            <h5 class="ms-layer video-title video-top-title" style="left:243px; top:29px "
                data-effect="left(150)"
                data-duration="3500"
                data-ease="easeOutExpo"
                data-delay="50"
            >DIRECTOR’S CUT</h5>

            <h4 class="ms-layer video-title" style="left:240px; top:44px "
                data-effect="front(500)"
                data-duration="5000"
                data-ease="easeOutExpo"
                data-delay="400"
            >CHEETAHS ON THE EDGE</h4>

            <h5 class="ms-layer video-title video-sub-title" style="left:240px; top:90px "
                data-effect="right(50)"
                data-duration="3500"
                data-ease="easeOutExpo"
                data-delay="1000"
            >Groundbreaking footage of the world’s fastest runner</h5>

        </div>
        <div class="ms-slide">
            <img src="<?php echo $resource_path; ?>/images/gallery/blank.gif" data-src="<?php echo $resource_path; ?>/images/gallery/5.jpg" alt="lorem ipsum dolor sit" />
            <img src="<?php echo $resource_path; ?>/images/gallery/5-thumb.jpg" alt="thumb-5" class="ms-thumb" />
            <div class="ms-info">
                CONSECTETUR ADIPISCING ELIT
            </div>
        </div>
        <div class="ms-slide">
            <img src="<?php echo $resource_path; ?>/images/gallery/blank.gif" data-src="<?php echo $resource_path; ?>/images/gallery/6.jpg" alt="lorem ipsum dolor sit" />
            <img src="<?php echo $resource_path; ?>/images/gallery/6-thumb.jpg" alt="thumb-6" class="ms-thumb" />
            <div class="ms-info">
                SED A SEM AT LIBERO SODALES
            </div>
        </div>
        <div class="ms-slide">
            <img src="<?php echo $resource_path; ?>/images/gallery/blank.gif" data-src="<?php echo $resource_path; ?>/images/gallery/7.jpg" alt="lorem ipsum dolor sit" />
            <img src="<?php echo $resource_path; ?>/images/gallery/7-thumb.jpg" alt="thumb-7" class="ms-thumb" />
            <div class="ms-info">
                AT LACUS SED RUTRUM
            </div>
        </div>
        <div class="ms-slide">
            <img src="<?php echo $resource_path; ?>/images/gallery/blank.gif" data-src="<?php echo $resource_path; ?>/images/gallery/8.jpg" alt="lorem ipsum dolor sit" />
            <img src="<?php echo $resource_path; ?>/images/gallery/8-thumb.jpg" alt="thumb-8" class="ms-thumb" />
            <div class="ms-info">
                VITAE ULTRICIES ALIQUET
            </div>
        </div>
    </div>
    <!-- end of masterslider -->
</div>